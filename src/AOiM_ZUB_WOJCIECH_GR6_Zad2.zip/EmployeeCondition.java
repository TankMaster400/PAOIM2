public enum EmployeeCondition
{
    obecny,
    delegacja,
    chory,
    nieobecny
}
